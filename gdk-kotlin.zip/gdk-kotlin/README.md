# gdk-kotlin
Google Developers Kejar 2018 Batch 2 untuk kelas "Kotlin on Android"
