package burhanarifm.footballclubs.utils.domains

data class Club (val name: String?, val image: Int?, val desc: String?)